#!/bin/sh
# Julien TIERNY <julien.tierny@lifl.fr>, 2007.

# Directory where are stored the GTS file (dataset) 
# Example DATASET_PATH=~/mydataset
DATASET_PATH=
# Directory that contains `sinamis'
SINAMIS_PATH=
# Filename for the dataset index (output).
INDEX_FILE=

if [ -z "$DATASET_PATH" ] || [ -z "$INDEX_FILE" ] || [ -z "$SINAMIS_PATH" ] ; 
then
	echo "Please first edit this script file to configure it!"
	exit 255
fi

if [ -e $INDEX_FILE ];then
	echo "Replacing previous version of $INDEX_FILE."
	mv $INDEX_FILE $INDEX_FILE.old
fi

for ENTRY in $DATASET_PATH/*.gts; do
	echo "Indexing $ENTRY...";
	RET=0
	$SINAMIS_PATH/sinamis -i $INDEX_FILE -n $ENTRY > /dev/null  2> /dev/null \
		&& RET=1
	if [ "$RET" -eq "0" ]; then
		echo "ERROR: could not process $QUERY!!!"
	fi
done

if [ -e $INDEX_FILE ]; then
	chmod -w $INDEX_FILE
fi
