#!/bin/sh
# Julien TIERNY <julien.tierny@lifl.fr>, 2007.

# Directory where are stored the GTS file (queryset) 
# Example: QUERYSET_PATH=~/myqueryset
QUERYSET_PATH=
# Directory that contains `sinamis'
SINAMIS_PATH=
# Filename for the database index.
INDEX_FILE=
# Filename for score file (output)
SCORE_FILE=

if [ -z "$QUERYSET_PATH" ] || [ -z "$INDEX_FILE" ] || [ -z "$SINAMIS_PATH" ] \
	|| [ -z "$SCORE_FILE" ]; 
then
	echo "Please first edit this script file to configure it!"
	exit 255
fi

if [ -e $SCORE_FILE ]; then
	echo "Replacing previous version of $SCORE_FILE."
	mv $SCORE_FILE $SCORE_FILE.old
fi

for QUERY in $QUERYSET_PATH/*.gts; do
	echo "Computing score for $QUERY...";
	RET=0
	$SINAMIS_PATH/sinamis -i $INDEX_FILE -q $QUERY -s $SCORE_FILE \
		> /dev/null && RET=1
	if [ "$RET" -eq "0" ]; then
		echo "ERROR: could not process $QUERY!!!"
	fi
done

if [ -e $SCORE_FILE ]; then
	chmod -w $SCORE_FILE
fi
