#include                  <Blank.h>

using namespace std;
using namespace ttk;
using namespace blank;

Blank::Blank(){

  inputData_ = NULL;
  outputData_ = NULL;
  triangulation_ = NULL;
}

Blank::~Blank(){
  
}

