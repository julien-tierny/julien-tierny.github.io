#include                  <MorseSmaleComplex.h>

using namespace std;
using namespace ttk;

MorseSmaleComplex::MorseSmaleComplex():
  dimensionality_{},
  abstractMorseSmaleComplex_{}
{}

MorseSmaleComplex::~MorseSmaleComplex(){
}

