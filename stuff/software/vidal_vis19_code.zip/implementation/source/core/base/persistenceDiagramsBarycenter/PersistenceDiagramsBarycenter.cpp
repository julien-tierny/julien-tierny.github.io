#include                  <PersistenceDiagramsBarycenter.h>


