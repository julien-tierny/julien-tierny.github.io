## TTK - The Topology ToolKit 

[![BSD licensed](https://api.travis-ci.org/topology-tool-kit/ttk.svg)](https://travis-ci.org/topology-tool-kit/ttk) [![BSD licensed](https://img.shields.io/badge/license-BSD-blue.svg?maxAge=2592000)](https://github.com/topology-tool-kit/ttk/blob/master/LICENSE) [![Release version](https://img.shields.io/github/release/topology-tool-kit/ttk.svg?maxAge=86400)](https://github.com/topology-tool-kit/ttk/releases/latest) 

Topological Data Analysis and Visualization

https://topology-tool-kit.github.io/


