#!/bin/bash

fileList=""
for((I=0; I < 48; I++)); do
  fileList="$fileList -i seaSurfaceHeight_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsClusteringCmd $fileList -o output_clustering_seaSurfaceHeight -d 1 -T 10 -K 4 -t 1
