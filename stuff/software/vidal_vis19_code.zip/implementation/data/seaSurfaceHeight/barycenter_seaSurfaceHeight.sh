#!/bin/bash

fileList=""
for((I=0; I < 48; I++)); do
  fileList="$fileList -i seaSurfaceHeight_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsBarycenterCmd $fileList -o output_barycenter_seaSurfaceHeight -d 1 -t 1
