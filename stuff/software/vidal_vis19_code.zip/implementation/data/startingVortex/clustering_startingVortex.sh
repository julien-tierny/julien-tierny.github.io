#!/bin/bash

fileList=""
for((I=0; I < 12; I++)); do
  fileList="$fileList -i startingVortex_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsClusteringCmd $fileList -o output_clustering_startingVortex -d 1 -T 10 -t 1 -G 0.9 -K 2
