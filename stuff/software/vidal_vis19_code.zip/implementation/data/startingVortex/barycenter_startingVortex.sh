#!/bin/bash

fileList=""
for((I=0; I < 12; I++)); do
  fileList="$fileList -i startingVortex_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsBarycenterCmd $fileList -o output_barycenter_startingVortex -d 1 -t 1
