#!/bin/bash

fileList=""
for((I=0; I < 12; I++)); do
  fileList="$fileList -i isabel_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsClusteringCmd $fileList -o output_clustering_isabel -d 1 -T 10 -G 0.8 -K 3 -P 2 -t 1
