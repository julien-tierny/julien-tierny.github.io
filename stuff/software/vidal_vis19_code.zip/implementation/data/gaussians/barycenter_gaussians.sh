#!/bin/bash

fileList=""
for((I=0; I < 100; I++)); do
  fileList="$fileList -i ./gaussians_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsBarycenterCmd $fileList -o output_barycenter_gaussians -d 1 -t 1
