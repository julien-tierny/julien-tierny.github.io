#!/bin/bash

fileList=""
for((I=0; I < 100; I++)); do
  fileList="$fileList -i ./gaussians_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsClusteringCmd $fileList -o output_clustering_gaussians -d 1 -T 10 -G .35 -K 3 -P 2 -t 1
