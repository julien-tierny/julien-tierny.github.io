#!/bin/bash

fileList=""
for((I=0; I < 45; I++)); do
  fileList="$fileList -i vortexStreet_diagrams/diagram_"$I".vtu"
done
../../install/bin/ttkPersistenceDiagramsClusteringCmd $fileList -o output_clustering_vortexStreet -d 1 -T 10 -K 5 -t 1

