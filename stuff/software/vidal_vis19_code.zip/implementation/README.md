

## INSTALLATION:

### Installing the dependencies:

Several dependencies will need to be installed in order to compile the code. 
Please enter the following commands (omit the $
character) in a terminal to install them (please see the documentation of your
package manager if your operating system is not Ubuntu Linux 18.04):
```bash
$ sudo apt install cmake-qt-gui
$ sudo apt install libvtk7-dev
$ sudo apt install qt5-default qttools5-dev libqt5x11extras5-dev
```
Note that these commands will also trigger the installation of the (numerous)
dependencies of these components.

### Extracting the zip file:
Move the zip file to your working directory, and extract it using the
following command : 
```bash
$ unzip implementation.zip
```
Move to the decompressed folder : 
```bash
$ cd implementation
```

### Configuring, compiling and installing:
Enter the following command to start the configuration menu for the code's
build : 
```bash
$ cd source/
$ mkdir build
$ cd build/
$ cmake-gui ../
```
The configuration windows opens. Proceed as follows :
1. Click on the "Configure" button. Use the default settings in the pop-up
   window.
2. After configuration, make sure that the following variables are set as follows :  
  * CMAKE_INSTALL_PREFIX = `../../install`
  * TTK_BUILD_PARAVIEW_PLUGINS = OFF
  * TTK_BUILD_STANDALONE_APPS = ON
3. Click on the "Generate" button and close the configuration window when the generation is completed.

In order to build the project, enter the following command, where `N` is the number of available cores on your system (this will take a **LONG** time):
```bash
$ make -jN
```
Once the build is finished, enter the following command to install the project
in the *install* folder:
```bash
$ make install
```

## REPRODUCING THE RESULTS FROM THE PAPER:

The *data* folder contains one folder for each ensemble data-set used in the paper.
Inside is a folder containing all the precomputed
persistence diagrams for the data-set. Alongside, two *bash* scripts allow to
reproduce the quantitative results of the section 5 in the paper.
One script allows to run the barycenter computation on the data-set (Table 1.
in the paper). The other one carries out the clustering.

For instance for the *gaussians* data-set : 
```bash
$ cd data/gaussians/
$ ./barycenter_gaussians.sh
$ ./clustering_gaussians.sh
```

## VISUALIZING THE OUTPUTS:

The clustering results are displayed in the terminal. To understand the
result, it is easier to know the structure of the data : 

1. The *gaussians* data-set contains 100 members dispatched in 3 clusters : 25
for the first cluster, 50 for the second cluster and 25 for the third. As the
persistence diagrams are indexed in this order, the right clustering is the
following :
    ```
    Cluster 0 : [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    Cluster 1 : [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74]
    Cluster 2 : [75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99]
    ```

2. The *vortexStreet* data-set contains 45 members for 5 clusters. An example
   of a correct clustering is :
    ```
    Cluster 0 : [0, 1, 2, 3, 4, 5, 6, 7, 8]
    Cluster 1 : [27, 28, 29, 30, 31, 32, 33, 34, 35]
    Cluster 2 : [18, 19, 20, 21, 22, 23, 24, 25, 26]
    Cluster 3 : [36, 37, 38, 39, 40, 41, 42, 43, 44]
    Cluster 4 : [9, 10, 11, 12, 13, 14, 15, 16, 17]
    ```
3. The *startingVortex* data-set contains 12 members for 2 clusters. The
   expected output of the clustering is :
    ```
    Cluster 0 : [0, 1, 2, 3, 4, 5]
    Cluster 1 : [6, 7, 8, 9, 10, 11]
    ```

4. The *isabel* data-set counts 12 members in 3 clusters :
    ```
    Cluster 0 : [0, 1, 2, 3]
    Cluster 1 : [8, 9, 10, 11]
    Cluster 2 : [4, 5, 6, 7]
    ```

5. The *seaSurfaceHeight* contains 48 members, dispatched in 4 clusters. A
   correct clustering is :
    ```
    Cluster 0 : [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    Cluster 1 : [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
    Cluster 2 : [36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47]
    Cluster 3 : [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
    ```

Additionnally, the scripts create several output files :

Each **barycenter** script outputs 3 *.vtu* files, labeled **_port#0*, **_port#1* and  **_port#2*.
* The **_port#0* file contains the computed barycenter. 
* The **_port#1* file contains the input diagrams for the computation of the
barycenter.
* The **_port#2* file contains the information on the matchings between each
diagram and the barycenter.

Each **clustering** script outputs 2 *.vtu* files, labeled **_port#0* and **_port#1*.
* The **_port#0* file contains the initial input diagrams, labeled with the index
of their respective cluster.
* The **_port#1* file contains the centroids of each cluster, namely the
barycenter of the cluster of diagrams.

To visualize those *.vtu* files, you can use ParaView (www.paraview.org):
Install the packaged version with
```bash
$ sudo apt install paraview
```
You can then simply visualize the outputs of our approach, for instance for
the *gaussians* ensemble : 
```bash
$ paraview output_clustering_gaussians_port#0.vtu
```
Applying a Threshold on the *ID of Diagram* or *ID of Cluster* fields can help
you to better explore the output.


## USING THE STANDALONE EXECUTABLES:
-----------------------------------
The above installation have provided you with two executables files : 
**ttkPersistenceDiagramsBarycenterCmd** and
**ttkPersistenceDiagramsClusteringCmd**, available in `install/bin/`

You can directly use those in order to try out our implementation of our
method.
Simply entering one of those commands should list you the needed parameters.

For the barycenter computation : 
```
$ ./ttkPersistenceDiagramsBarycenterCmd 
[CommandLine] Missing mandatory argument:
[CommandLine]   -i <{Input data-sets (*.vti, *vtu, *vtp)}>
[CommandLine]
[CommandLine] Usage:
[CommandLine]   ./ttkPersistenceDiagramsBarycenterCmd
[CommandLine] Argument(s):
[CommandLine]   [-d <Global debug level (default: 3)>]
[CommandLine]   [-t <Global thread number (default: 16)>]
[CommandLine]   [-T <Time Limit for Computation, in seconds. No time limit by default (default: -1)>]
[CommandLine]   -i <{Input data-sets (*.vti, *vtu, *vtp)}>
[CommandLine]   [-o <Output file name base (no extension) (default: `output')>]
[CommandLine] Option(s):
```

For the clustering computation : 
```
$ ./ttkPersistenceDiagramsClusteringCmd
[CommandLine] Missing mandatory argument:
[CommandLine]   -i <{Input data-sets (*.vti, *vtu, *vtp)}>
[CommandLine]
[CommandLine] Usage:
[CommandLine]   ./ttkPersistenceDiagramsClusteringCmd
[CommandLine] Argument(s):
[CommandLine]   [-d <Global debug level (default: 3)>]
[CommandLine]   [-t <Global thread number (default: 16)>]
[CommandLine]   [-P <Set the type of critical pairs considered in the clustering. 
			-1 : all critical pairs
			 0 : only min-saddle pairs 
			 1 : onlysaddle-saddle pairs
			 2 : only saddle-max pairs
		 (default: -1)>]
[CommandLine]   [-K <Number of Clusters (default: 1)>]
[CommandLine]   [-T <Time Limit for Computation, in seconds. No time limit by default (default: -1)>]
[CommandLine]   [-G <Geometry Penalization, bet 0. and 1., 1. means no lifting (default: 1)>]
[CommandLine]   -i <{Input data-sets (*.vti, *vtu, *vtp)}>
[CommandLine]   [-o <Output file name base (no extension) (default: `output')>]
[CommandLine] Option(s):
```
A standard exemple for the barycenter computation of two persistence diagrams
within 1 second and minimal verbosity is :
```bash
$ ttkPersistenceDiagramsBarycenterCmd -i diagram1.vtu -i diagram2.vtu -o output_barycenter -T 1 -d 1 
```

Look at the provided scripts for more examples on how to use those commands.


## COMPUTING YOUR OWN DIAGRAMS:
------------------------------

If you want to test our approach on your own data,
you will need to pre-compute the persistence diagrams.
For this purpose, we provide the implementation of Gueunet et al., available
in the Topology ToolKit (https://topology-tool-kit.github.io/).

Note that your data must be in a *.vtu* or *.vti* format.

Simply use the **ttkPersistenceDiagramCmd** command as so :
```bash
$ ttkPersistenceDiagramCmd  -i your_vtu_or_vti_data_file -o output_diagram.vtu -F your_scalarField_index_in_the_data
```
