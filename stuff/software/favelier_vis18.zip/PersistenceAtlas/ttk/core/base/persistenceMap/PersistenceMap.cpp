#include                  <PersistenceMap.h>

PersistenceMap::PersistenceMap(){

  inputData_ = NULL;
  outputData_ = NULL;
  triangulation_ = NULL;
}

PersistenceMap::~PersistenceMap(){
  
}

