#include                  "LDistance.h"

LDistance::LDistance() {

  inputData1_ = NULL;
  inputData2_ = NULL;
  outputData_ = NULL;
	
  numberOfPoints_ = 0;
}

LDistance::~LDistance() {
  
}
